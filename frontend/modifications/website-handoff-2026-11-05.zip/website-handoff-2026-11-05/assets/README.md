# Handoff assets

| File | What it is |
|---|---|
| `Logo_Design_Orange.svg` | New VoloLeads logo, the only version in use. 1348×1345, transparent; embeds a raster image. |
| `Logo_Design_Orange.png` | PNG of the same logo (use for favicon generation and as a fallback) |
| `one-caller-one-month.png` | Proof image, 2400×1350: Dave (pseudonym), July 2026, real KPI figures |
| `four-month-consistency.png` | Proof image, 2400×1350: Charlie (pseudonym), May–August 2026, real KPI figures |
| `one-caller-one-month.html`, `four-month-consistency.html` | Editable sources for the proof images (render with headless Chrome; see the handoff, section 6) |
| `logo-orange.png` | Copy of the logo used by the HTML sources |

Rules: use the logo unchanged, and never change the figures in the proof images.
