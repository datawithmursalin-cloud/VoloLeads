# VoloLeads Website Handoff (November 5, 2026)

Complete package for the website front-end agent. **Start with [WEBSITE_HANDOFF.md](WEBSITE_HANDOFF.md).** It holds every change, decision and checklist item. Everything it references is in this folder.

## Contents

- `WEBSITE_HANDOFF.md`: the full handoff (brand, homepage, mega menu, services pages, pricing, proof rules, tech, checklist)
- `assets/`: new orange logo (SVG + PNG) and the two proof images (PNG + editable HTML sources). See [assets/README.md](assets/README.md).

## How to use

Give the whole folder (or the zip of it) to the website agent. Ask them to work through `WEBSITE_HANDOFF.md` section by section and report back with the items in section 10.

## Notes for the owner

- This consolidates `../website_update_nov_4.md` and `../website_services_pages_nov_5.md`, which remain as history. Edit this folder from now on.
- PNG files are ignored by Git and stay local; the zip for sharing is `../website-handoff-2026-11-05.zip`.
- Open decisions are listed in section 9 of the handoff.
